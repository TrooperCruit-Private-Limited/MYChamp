﻿namespace MYChamp.Models
{
    public class VisitUsInformationModel
    {
        public int Id { get; set; }
        public string? Icon { get; set; }
        public string? ImageType { get; set; }
        public string? Name { get; set; }
        public string? Link { get; set; }
        public int Active { get; set; }
    }
}
