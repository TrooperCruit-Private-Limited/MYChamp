﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MYChamp.Models
{
    public class Article
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Required]
        [Column("title")]
        public string Title { get; set; }
        [ValidateNever]
        [Column("filepath")]
        public string FilePath { get; set; } = "";
        [NotMapped]
        [ValidateNever]
        public IFormFile formFile { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("relevancy")]
        public string Relevancy { get; set; }
        [Column("medialinks")]
        public string MediaLinks { get; set; }


        [ValidateNever]
        [Column("coverimagepath")]
        public string CoverImagePath { get; set; } = "";
        [NotMapped]
        [ValidateNever]
        public IFormFile Coverpath { get; set; }
        [Column("category")]
        public string Category { get; set; }
        //[Required]
        //[ValidateNever]
        [Column("useremail")]
        public string UserEmail { get; set; }
        [Column("rating")]
        public double Rating { get; set; }
        [Column("isarchived")]
        public bool IsArchived { get; set; }
        [Column("author")]
        public string Author { get; set; }
        [Column("authorposition")]
        public string AuthorPosition { get; set; }
    }
}
