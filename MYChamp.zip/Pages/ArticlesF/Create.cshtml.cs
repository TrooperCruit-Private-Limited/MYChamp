using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MYChamp.DbContexts;
using MYChamp.Models;
using Microsoft.AspNetCore.Hosting;
using System;
using System.IO;

namespace MYChamp.Pages.ArticlesF
{
    [BindProperties]
    public class CreateModel : PageModel
    {
        private readonly MYChampDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
       
        public Article Article { get; set; }
     

        public CreateModel(MYChampDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
            
        }

        public void OnGet()
        {
            Article = new Article();
            Article.UserEmail = HttpContext.Session.GetString("username");
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                string wwwRootPath = _webHostEnvironment.WebRootPath;

                
                if (Article.formFile != null)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Article.formFile.FileName);
                    string filePath = Path.Combine(wwwRootPath, @"images\ArticleImg", fileName);

                    using (var filestream = new FileStream(filePath, FileMode.Create))
                    {
                        Article.formFile.CopyTo(filestream);
                    }
                   
                    Article.FilePath = @"\images\ArticleImg\" + fileName;
                }

                
                if (Article.Coverpath != null)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Article.Coverpath.FileName);
                    string filePath = Path.Combine(wwwRootPath, @"images\ArticleImg", fileName);

                    using (var filestream = new FileStream(filePath, FileMode.Create))
                    {
                        Article.Coverpath.CopyTo(filestream);
                    }

                    Article.CoverImagePath = @"\images\ArticleImg\" + fileName;

                    
                }
                //Article.UserEmail = HttpContext.Session.GetString("username");
                _context.Articles.Add(Article);
                _context.SaveChanges();
                TempData["SuccessMessage"] = "Article Added sucessfully";
                return RedirectToPage("Index");
            }
            return Page();
        }
    }
}
