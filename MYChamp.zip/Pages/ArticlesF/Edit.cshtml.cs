using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MYChamp.DbContexts;
using MYChamp.Models;

namespace MYChamp.Pages.ArticlesF
{
    [BindProperties]
    public class EditModel : PageModel
    {
        private readonly MYChampDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public Article Article { get; set; }

        public EditModel(MYChampDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public void OnGet(int? id)
        {
            if (id != null && id != 0)
            {
                Article = _context.Articles.Find(id);
            }
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {

                string wwwRootPath = _webHostEnvironment.WebRootPath;

                // Handle FilePath
                if (Article.formFile != null)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Article.formFile.FileName);
                    string filePath = Path.Combine(wwwRootPath, @"images\ArticleImg", fileName);

                    using (var filestream = new FileStream(filePath, FileMode.Create))
                    {
                        Article.formFile.CopyTo(filestream);
                    }


                    if (!string.IsNullOrEmpty(Article.FilePath))
                    {
                        string oldFilePath = Path.Combine(wwwRootPath, Article.FilePath.TrimStart('\\'));
                        if (System.IO.File.Exists(oldFilePath))
                        {
                            System.IO.File.Delete(oldFilePath);
                        }
                    }

                    Article.FilePath = @"\images\ArticleImg\" + fileName;
                }

                if (Article.Coverpath != null)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Article.Coverpath.FileName);
                    string filePath = Path.Combine(wwwRootPath, @"images\ArticleImg", fileName);

                    using (var filestream = new FileStream(filePath, FileMode.Create))
                    {
                        Article.Coverpath.CopyTo(filestream);
                    }


                    if (!string.IsNullOrEmpty(Article.CoverImagePath))
                    {
                        string oldCoverPath = Path.Combine(wwwRootPath, Article.CoverImagePath.TrimStart('\\'));
                        if (System.IO.File.Exists(oldCoverPath))
                        {
                            System.IO.File.Delete(oldCoverPath);
                        }
                    }

                    Article.CoverImagePath = @"\images\ArticleImg\" + fileName;
                }

                if (string.IsNullOrEmpty(Article.FilePath))
                {
                    Article.FilePath = "";
                }
                if (string.IsNullOrEmpty(Article.CoverImagePath))
                {
                    Article.CoverImagePath = "";
                }

                _context.Attach(Article).State = EntityState.Modified;
                _context.SaveChanges();
                TempData["SuccessMessage"] = "Article updated sucessfully";
                return RedirectToPage("./Index");
            }
            return Page();
        }
    }
}
