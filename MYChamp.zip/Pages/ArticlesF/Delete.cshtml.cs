using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MYChamp.DbContexts;
using MYChamp.Models;
using System.Linq;

namespace MYChamp.Pages.ArticlesF
{
    [BindProperties]
    public class DeleteModel : PageModel
    {
        private readonly MYChampDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public Article Article { get; set; }

        public DeleteModel(MYChampDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public void OnGet(int? id)
        {
            if (id.HasValue && id.Value != 0)
            {
                Article = _context.Articles.FirstOrDefault(a => a.Id == id.Value);
            }
        }

        public IActionResult OnPost()
        {
            if (Article?.Id != null)
            {
                var articleToDelete = _context.Articles.FirstOrDefault(a => a.Id == Article.Id);

                if (articleToDelete != null)
                {
                 
                    Console.WriteLine($"FilePath: {articleToDelete.FilePath}");
                    Console.WriteLine($"CoverImagePath: {articleToDelete.CoverImagePath}");

                    if (!string.IsNullOrEmpty(articleToDelete.FilePath))
                    {
                        string wwwRootPath = _webHostEnvironment.WebRootPath;
                        string filePath = Path.Combine(wwwRootPath, articleToDelete.FilePath.TrimStart('\\'));

                        if (System.IO.File.Exists(filePath))
                        {
                            System.IO.File.Delete(filePath);
                        }
                    }

                    if (!string.IsNullOrEmpty(articleToDelete.CoverImagePath))
                    {
                        string wwwRootPath = _webHostEnvironment.WebRootPath;
                        string coverPath = Path.Combine(wwwRootPath, articleToDelete.CoverImagePath.TrimStart('\\'));

                        if (System.IO.File.Exists(coverPath))
                        {
                            System.IO.File.Delete(coverPath);
                        }
                    }

                    _context.Articles.Remove(articleToDelete);
                    _context.SaveChanges();
                    TempData["SuccessMessage"] = "Article deleted sucessfully";
                }
            }

            return RedirectToPage("./Index");
        }
    }
}
